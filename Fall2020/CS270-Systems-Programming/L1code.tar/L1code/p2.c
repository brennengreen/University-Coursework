void test_int(int a); 

int main()
{
    test_int(40000);
    test_int(50000);
}
