//--------------------------------------------------------
//  CS 215 - 006 - Fall 2019
//	Project 3: The New Link Blue
//	By: Brennen Green
//	Received Help From: No one
//--------------------------------------------------------
#include <iostream>
#include "userint.h"

//-------------------------------------------------------------------
//                               main
//-------------------------------------------------------------------
// Control main program flow
int main() {
	// create the app and start it!
	userint x;
	x.go();
	system("pause");
	return 0;
}