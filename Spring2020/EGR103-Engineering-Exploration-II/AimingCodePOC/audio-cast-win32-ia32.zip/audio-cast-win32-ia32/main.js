'use strict';

var _electron = require('electron'),
    electron = require('electron'),
    app = electron.app,
    BrowserWindow = electron.BrowserWindow,
    lib,
    contextMenu = new _electron.Menu();

contextMenu.append(new _electron.MenuItem({
    type: 'separator'
}));

contextMenu.append(new _electron.MenuItem({
    type: 'normal',
    label: 'Close',
    click: function click() {
        lib.quit();
        app.quit();
    }
}));

app.commandLine.appendSwitch('v', -1);
app.commandLine.appendSwitch('vmodule', 'console=0');
app.commandLine.appendSwitch('disable-speech-api');

app.on('ready', function () {
    lib = require('./lib');
    console.info(process.cwd());
    var appIcon = new _electron.Tray('cast.png');
    appIcon.on('click', function (ev, bounds) {
        console.info(bounds);
        appIcon.popUpContextMenu(contextMenu, { x: bounds.x, y: bounds.y - bounds.height });
    });
    appIcon.on('right-click', function (ev, bounds) {
        console.info(ev, bounds);
        appIcon.popUpContextMenu(contextMenu, { x: bounds.x, y: bounds.y - bounds.height * 2 });
    });
    lib.on("deviceFound", function (host, devicename) {
        console.log(host, devicename);
        contextMenu.insert(0, new _electron.MenuItem({
            label: devicename,
            type: 'checkbox',
            click: function click() {
                lib.stream(host);
            }
        }));
        appIcon.setContextMenu(contextMenu);
    });
});

app.on('window-all-closed', app.quit);
