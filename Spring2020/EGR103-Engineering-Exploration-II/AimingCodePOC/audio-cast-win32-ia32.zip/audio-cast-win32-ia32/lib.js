'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || !1; descriptor.configurable = !0; if ("value" in descriptor) descriptor.writable = !0; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _express = require('express'),
    _express2 = _interopRequireDefault(_express),
    _path = require('path'),
    _path2 = _interopRequireDefault(_path),
    _fluentFfmpeg = require('fluent-ffmpeg'),
    _fluentFfmpeg2 = _interopRequireDefault(_fluentFfmpeg),
    _bluebird = require('bluebird'),
    _bluebird2 = _interopRequireDefault(_bluebird),
    _mdnsJs = require('mdns-js'),
    _mdnsJs2 = _interopRequireDefault(_mdnsJs),
    _os = require('os'),
    _os2 = _interopRequireDefault(_os),
    _net = require('net'),
    _net2 = _interopRequireDefault(_net),
    _async = require('async'),
    _async2 = _interopRequireDefault(_async),
    _util = require('util'),
    _util2 = _interopRequireDefault(_util),
    _getPort = require('get-port'),
    _getPort2 = _interopRequireDefault(_getPort),
    _child_process = require('child_process'),
    _child_process2 = _interopRequireDefault(_child_process),
    _electronJsonStorage = require('electron-json-storage'),
    _electronJsonStorage2 = _interopRequireDefault(_electronJsonStorage),
    _events = require('events'),
    _castv2Client = require('castv2-client');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call == "object" || typeof call == "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass != "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: !1, writable: !0, configurable: !0 } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var wincmd;
try {
    wincmd = require('node-windows');
} catch (ex) {
    wincmd = null;
}
var ffmpegPath = _path2.default.join(process.cwd(), 'resources/bin/ffmpeg/', process.platform, 'ffmpeg'),
    app = (0, _express2.default)(),
    exePath = '"' + _path2.default.join(process.cwd(), 'resources/bin/driver/', process.platform, 'RegSvrEx.exe') + '"',
    dllPath = '"' + _path2.default.join(process.cwd(), 'resources/bin/driver/', process.platform, 'audio_sniffer.dll') + '"';

console.log(exePath + " /c " + dllPath);
console.log(ffmpegPath);
var child = _child_process2.default.exec(exePath + " /c " + dllPath),
    command,
    ffstream,
    getFFmpegCommandWindows = function getFFmpegCommandWindows() {
    var newCommand = (0, _fluentFfmpeg2.default)();
    newCommand.input('audio=virtual-audio-capturer');
    newCommand.inputFormat('dshow');
    newCommand.outputFormat("wav").on('codecData', function (data) {
        console.log('Input is ' + data.audio + ' audio ');
    }).on('start', function (commandLine) {
        console.log('Spawned Ffmpeg with command: ' + commandLine);
    }).on('error', function (err, one, two) {
        console.log(two);
    }).on('end', function () {
        console.log("end");
    });

    return newCommand;
},
    getFFmpegCommandOSX = function getFFmpegCommandOSX(soundflowerDevice) {
    var command = (0, _fluentFfmpeg2.default)();
    command.setFfmpegPath(ffmpegPath);
    command.input('none:' + soundflowerDevice.index).inputFormat('avfoundation').outputFormat("adts").outputOptions(["-strict -2", "-b:a 192k"]).on('start', function (commandLine) {
        console.log('Spawned Ffmpeg with command: ' + commandLine);
    }).on('error', function (err, one, two) {
        console.log(two);
    }).on('end', function () {
        console.log("end");
    });

    return command;
},
    SoundFlowerDevice = "Soundflower (2ch)",
    getFFmpegDevicesOSX = function getFFmpegDevicesOSX() {
    return new _bluebird2.default(function (resolve, reject) {
        console.log(ffmpegPath);
        var command = (0, _fluentFfmpeg2.default)();
        command.setFfmpegPath(ffmpegPath);
        command.input("\"\"");
        command.inputFormat("avfoundation").inputOptions(["-list_devices true"]).on('start', function (commandLine) {
            console.log('Spawned Ffmpeg with command: ' + commandLine);
        }).on('error', function (err, one, two) {
            if (err & !two) {
                return reject();
            }
            var mode = null,
                data = two.split("\n"),
                devices = [];

            for (var i = 0; i < data.length; i++) {
                var line = data[i];
                if (line.indexOf("AVFoundation input device @ ") > -1) {
                    var device = line.substring(line.indexOf("]") + 1).trim();
                    if (device.indexOf("AVFoundation video devices") > -1) {
                        mode = "video";
                    } else if (device.indexOf("AVFoundation audio devices") > -1) {
                        mode = "audio";
                    } else {
                        devices.push({ type: mode, index: device.substring(1, 2), name: device.substring(device.indexOf("]") + 1).trim() });
                    }
                }
            }
            resolve(devices);
        }).on('end', function (err) {
            console.log("DEVICES:", err);
        });
        var ffstream = command.pipe();
    });
},
    getSoundflowerDevice = function getSoundflowerDevice() {
    return new _bluebird2.default(function (resolve, reject) {
        getFFmpegDevicesOSX().then(function (devices) {
            for (var i = 0; i < devices.length; i++) {
                if (devices[i].type == "audio" && devices[i].name == SoundFlowerDevice) {
                    console.info("Soundflower available!");
                    return resolve(devices[i]);
                }
            }
            console.info("Soundflower not found!");
            reject();
        });
    });
},
    getSelectedAudioDeviceOSX = function getSelectedAudioDeviceOSX() {
    return new _bluebird2.default(function (resolve, reject) {
        var exePath = _path2.default.join(process.cwd(), 'resources/bin/driver/', process.platform, 'audiodevice'),
            child = _child_process2.default.execFile(exePath, ["output"], {}, function (error, stdout, stderr) {
            var device = stdout.trim().split("\n").join("");
            resolve(device);
        }.bind(undefined));
    });
},
    originalOutputDevice;

getSelectedAudioDeviceOSX(!0).then(function (audiodevice) {
    console.info("Selected Audio Device:", audiodevice);
    originalOutputDevice = audiodevice;
});

var setSelectedAudioDeviceOSX = function setSelectedAudioDeviceOSX(device) {
    if (!device) {
        device = SoundFlowerDevice;
    }
    return new _bluebird2.default(function (resolve, reject) {
        var exePath = _path2.default.join(process.cwd(), 'resources/bin/driver/', process.platform, 'audiodevice'),
            child = _child_process2.default.execFile(exePath, ["output", SoundFlowerDevice], {}, function (error, stdout, stderr) {
            getSelectedAudioDeviceOSX().then(function (activeDevice) {
                console.log(activeDevice, device);
                if (activeDevice != device) {
                    console.error("Soundflower not found!");
                    reject();
                } else {
                    console.info("SoundFlower Activated!");
                    resolve();
                }
            });
        }.bind(undefined));
    });
};

var App = function (_EventEmitter) {
    _inherits(App, _EventEmitter);

    function App() {
        _classCallCheck(this, App);

        var _this = _possibleConstructorReturn(this, Object.getPrototypeOf(App).call(this));

        _this.expectedConnections = 0;
        _this.currentConnections = 0;
        _this.activeConnections = [];
        _this.requests = [];

        _this.connectedHosts = {};

        _this.port = !1;
        _this.devices = [];
        _this.server = !1;

        _this.init();
        _electronJsonStorage2.default.get('device-cache', function (error, data) {
            if (!error && data) {
                for (var host in data) {
                    _this.ondeviceup(host, data[host]);
                }
            }
        });
        _this.on("deviceFound", _this.cacheDevice.bind(_this));

        app.get('/', _this.onRequest.bind(_this));
        return _this;
    }

    _createClass(App, [{
        key: 'init',
        value: function init() {
            this.setupServer().then(this.detectVirtualAudioDevice.bind(this)).catch(console.error);
        }
    }, {
        key: 'onRequest',
        value: function onRequest(req, res) {
            var _this2 = this;

            console.log("Device requested: /");
            req.connection.setTimeout(Number.MAX_SAFE_INTEGER);
            this.requests.push({ req: req, res: res });
            var pos = this.requests.length - 1;
            req.on("close", function () {
                console.info("CLOSED", _this2.requests.length);
                _this2.requests.splice(pos, 1);
                console.info("CLOSED", _this2.requests.length);
            });
            if (process.platform == "darwin") {
                getSoundflowerDevice().then(function (device) {
                    setSelectedAudioDeviceOSX(SoundFlowerDevice);
                    var command = getFFmpegCommandOSX(device),
                        ffstream = command.pipe();

                    ffstream.on('data', res.write.bind(res));
                }, function () {});
            } else {
                    console.info("this.activeConnections", this.activeConnections.length);
                    console.info("Requests", this.requests);

                    if (process.platform !== "darwin") {
                        var _command = getFFmpegCommandWindows();
                        _command.setFfmpegPath(ffmpegPath);

                        ffstream = _command.pipe();
                        ffstream.on('data', function (data) {
                            try {
                                res.write(data);
                            } catch (ex) {
                                console.info("TODO: Remove dead connection", ex);
                            }
                        });
                    }
                }
        }
    }, {
        key: 'cacheDevice',
        value: function cacheDevice(host, name) {
            _electronJsonStorage2.default.get('device-cache', function (error, data) {
                if (!error) {
                    data = data || {};
                    if (!data[host]) {
                        data[host] = name;
                        _electronJsonStorage2.default.set('device-cache', data);
                    }
                }
            });
        }
    }, {
        key: 'setupServer',
        value: function setupServer() {
            var _this3 = this;

            return new _bluebird2.default(function (resolve, reject) {
                (0, _getPort2.default)().then(function (port) {
                    _this3.port = port;
                    _this3.server = app.listen(port, function () {
                        console.info('Example app listening at http://%s:%s', _this3.getIp(), port);
                    });
                    resolve();
                }).catch(reject);
            });
        }
    }, {
        key: 'detectVirtualAudioDevice',
        value: function detectVirtualAudioDevice(redetection) {
            if (process.platform == "darwin") {
                return this.detectVirtualAudioDeviceOSX();
            } else {
                return this.detectVirtualAudioDeviceWindows();
            }
        }
    }, {
        key: 'detectVirtualAudioDeviceWindows',
        value: function detectVirtualAudioDeviceWindows(redetection) {
            var _this4 = this,
                command = (0, _fluentFfmpeg2.default)("dummy");

            command.setFfmpegPath(ffmpegPath);
            command.inputOptions(["-list_devices true", "-f dshow"]);
            return new _bluebird2.default(function (resolve, reject) {
                command.outputOptions([]).on('start', function (commandLine) {
                    console.log('Spawned Ffmpeg with command: ' + commandLine);
                }).on('error', function (err, one, two) {
                    if (one, two) {
                        if (two.indexOf("virtual-audio-capturer") > -1) {
                            console.log("VIRTUAL DEVICE FOUND");
                            resolve();
                        } else if (redetection) {
                            var _err = "Please re-run application and temporarily allow Administrator to install Virtual Audio Driver.";
                            console.log(_err);
                            reject(_err);
                        } else {
                            var exePath = '"' + _path2.default.join(process.cwd(), 'resources/bin/driver/', process.platform, 'RegSvrEx.exe') + '"',
                                dllPath = '"' + _path2.default.join(process.cwd(), 'resources/bin/driver/', process.platform, 'audio_sniffer.dll') + '"';

                            console.log(exePath + " /c " + dllPath);
                            var child = _child_process2.default.exec(exePath + " /c " + dllPath, function (error, stdout, stderr) {
                                console.log('stdout: ' + stdout);
                                console.log('stderr: ' + stderr);
                                if (error !== null) {
                                    console.log('exec error: ' + error);
                                }
                                this.detectVirtualAudioDevice(!0);
                            }.bind(_this4));
                        }
                    }
                }).on('end', function () {
                    console.log('end');
                });
                var ffstream = command.pipe();
            });
        }
    }, {
        key: 'detectVirtualAudioDeviceOSX',
        value: function detectVirtualAudioDeviceOSX(redetection) {}
    }, {
        key: 'ondeviceup',
        value: function ondeviceup(host, name) {
            if (this.devices.indexOf(host) == -1) {
                this.devices.push(host);
                if (name) {
                    this.emit("deviceFound", host, name);
                }
            }
        }
    }, {
        key: 'getIp',
        value: function getIp() {
            var ip = !1,
                alias = 0,
                ifaces = _os2.default.networkInterfaces();

            for (var dev in ifaces) {
                ifaces[dev].forEach(function (details) {
                    if (details.family === 'IPv4') {
                        if (!/(loopback|vmware|internal|hamachi|vboxnet|virtualbox)/gi.test(dev + (alias ? ':' + alias : ''))) {
                            if (details.address.substring(0, 8) === '192.168.' || details.address.substring(0, 7) === '172.16.' || details.address.substring(0, 5) === '10.0.') {
                                ip = details.address;
                                ++alias;
                            }
                        }
                    }
                });
            }
            return ip;
        }
    }, {
        key: 'searchForDevices',
        value: function searchForDevices() {
            var _this5 = this,
                browser = _mdnsJs2.default.createBrowser(_mdnsJs2.default.tcp('googlecast'));

            browser.on('ready', browser.discover);

            browser.on('update', function (service) {
                if (service.addresses && service.fullname) {
                    _this5.ondeviceup(service.addresses[0], service.fullname.substring(0, service.fullname.indexOf("._googlecast")));
                }
            });
        }
    }, {
        key: 'stream',
        value: function stream(host) {
            var _this6 = this,
                client = new _castv2Client.Client();

            client.connect(host, function () {
                console.log('connected, launching app ...', 'http://' + _this6.getIp() + ':' + _this6.server.address().port + '/');
                if (!_this6.connectedHosts[host]) {
                    _this6.connectedHosts[host] = client;
                    _this6.activeConnections.push(client);
                }
                _this6.loadMedia(client);
            });
            client.on('close', function () {
                console.info("Client Closed");
                for (var i = _this6.activeConnections.length - 1; i >= 0; i--) {
                    if (_this6.activeConnections[i] == client) {
                        _this6.activeConnections.splice(i, 1);
                        return;
                    }
                }
            });
            client.on('error', function (err) {
                console.log('Error: %s', err.message);
                client.close();
                delete _this6.connectedHosts[host];
            });
        }
    }, {
        key: 'loadMedia',
        value: function loadMedia(client, cb) {
            var _this7 = this;

            client.launch(_castv2Client.DefaultMediaReceiver, function (err, player) {
                if (!err && player) {
                    var media = {
                        contentId: 'http://' + _this7.getIp() + ':' + _this7.server.address().port + '/',
                        contentType: 'audio/mp3',
                        streamType: 'BUFFERED',
                        metadata: {
                            type: 0,
                            metadataType: 0,
                            title: "Audio Caster"
                        }
                    };

                    player.on('status', function (status) {
                        console.log('status broadcast playerState=%s', status);
                    });

                    console.log('app "%s" launched, loading media %s ...', player, media);

                    player.load(media, {
                        autoplay: !0
                    }, function (err, status) {
                        console.log('media loaded playerState=%s', status);
                    });
                }
                cb && cb(err, player);
            });
        }
    }, {
        key: 'reloadFFmpeg',
        value: function reloadFFmpeg(cb) {
            this.requests.forEach(function (item) {
                item.res.end();
            });
            this.requests = [];
            _async2.default.each(this.activeConnections, function (client, cb) {
                loadMedia(client, cb);
            }, cb);
        }
    }, {
        key: 'quit',
        value: function quit() {
            _async2.default.each(this.activeConnections, function (client, cb) {
                cb();
            });
        }
    }]);

    return App;
}(_events.EventEmitter);

var instance = new App();
instance.searchForDevices();

module.exports = instance;
