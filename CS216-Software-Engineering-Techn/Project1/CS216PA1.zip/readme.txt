===================== CS216 Project One Math Tutor =================================
Author: Brennen Green (Section 002)

Purpose: The purpose of this program is to create a tool for a person trying to learn
or get better at their arithmetic skills in the areas of multiplication, addition, and
subtraction. It accomplishes this by generating random numbers based on the type of
operation that the user wants to attempt

Compilation Instructions:
1. Enter the following at your shell prompt
g++ -O MathReport.cpp MathOperations.cpp PA1.cpp -o CS216PA1

2. Run the program by entering the following in your prompt
./CS216PA1
