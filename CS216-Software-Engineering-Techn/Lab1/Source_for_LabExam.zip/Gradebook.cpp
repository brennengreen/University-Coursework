/* 
 * File:   Gradebook.cpp
 * Course: CS216-00x
 * Project: Lab Exam
 * Purpose: provide the implementation of the member functions of the class named Gradebook
 *
 * Author: (your name)
 *
 */
#include <iostream>
#include "Gradebook.h"

// default constructor
Gradebook::Gradebook()
{
    // do nothing
    // vector class from STL provide default constructor
}

// return the size of the current vector: scores, 
// which represents current gradebook
int Gradebook::getSize() const
{
}

// insert a FinalGrade object, newFG, 
// into the end of the current gradebook
void Gradebook::insert(FinalGrade newFG)
{
}

// return a FinalGrade object, 
// which holds the maximum score in the current gradebook
FinalGrade Gradebook::getMax() const
{
}

// return a FinalGrade object,
// which holds the minimum score in the current gradebook
FinalGrade Gradebook::getMin() const
{
}

// return the average score among all scores in the current gradebook
double Gradebook::getAverage() const
{
}

// display the FinalGrade objects in the current gradebook
// display one object at each line
// For example:
// Score: 98.50    Letter Grade: A
void Gradebook::print() const
{
}

